<script>
    import Footer from "../Footer.svelte"
</script>



hei

<Footer/>